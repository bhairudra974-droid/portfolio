/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import { 
  Instagram, 
  Mail, 
  Menu, 
  X, 
  ArrowRight, 
  ExternalLink, 
  Layout, 
  Smartphone, 
  Cpu, 
  Palette,
  ChevronRight,
  Github
} from 'lucide-react';

// --- Types ---

interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
  tools: string[];
  process: string;
  outcome: string;
}

// --- Mock Data ---

const PROJECTS: Project[] = [
  {
    id: 'sneaker-poster',
    title: 'Sneaker Poster Design',
    category: 'Poster Design',
    description: 'Premium sneaker campaign poster focusing on dynamic movement and urban aesthetics.',
    image: 'https://picsum.photos/seed/sneaker/800/1000',
    tools: ['AI', 'Photopea', 'Canva'],
    process: 'The process involved generating high-fidelity AI assets for the background, followed by meticulous typography placement in Photopea to ensure a premium editorial feel.',
    outcome: 'A high-impact visual that successfully captured the energy of modern streetwear culture.'
  },
  {
    id: 'love-hope-trust',
    title: 'Love Hope Trust Poster',
    category: 'Visual Concepts',
    description: 'A minimalist exploration of human emotions through abstract geometry and typography.',
    image: 'https://picsum.photos/seed/abstract/800/1000',
    tools: ['Photoshop', 'AI'],
    process: 'Focused on negative space and bold serif typography to convey a sense of timelessness and emotional depth.',
    outcome: 'A series of posters that resonate on a personal level while maintaining a high-end aesthetic.'
  },
  {
    id: 'food-beverage',
    title: 'Food & Beverage Ad',
    category: 'Social Media Creatives',
    description: 'Commercial advertisement design for a premium beverage brand, emphasizing freshness.',
    image: 'https://picsum.photos/seed/drink/800/1000',
    tools: ['Photoshop', 'Canva'],
    process: 'Utilized color theory to enhance the visual appeal of the product, creating a refreshing and inviting atmosphere through lighting and texture.',
    outcome: 'Increased engagement for the brand across social platforms with a 25% higher click-through rate.'
  }
];

// --- Components ---

const Ruler = ({ orientation = 'horizontal' }: { orientation?: 'horizontal' | 'vertical' }) => (
  <div className={`absolute pointer-events-none opacity-20 ${
    orientation === 'horizontal' ? 'top-0 left-0 w-full h-4 ruler-marks-h' : 'top-0 left-0 h-full w-4 ruler-marks-v'
  }`} />
);

const TornPaperDivider = ({ top = false }: { top?: boolean }) => (
  <div className={`w-full h-10 bg-bg-soft ${top ? 'torn-paper-top' : 'torn-paper'}`} />
);

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Projects', href: '#projects' },
    { name: 'Services', href: '#services' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-bg-white/90 backdrop-blur-md py-4 shadow-sm' : 'bg-transparent py-6'
    }`}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
        <a href="#home" className="text-2xl font-display font-bold tracking-tighter">
          NOTELE<span className="text-accent-orange">GFX</span>
        </a>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              className="text-sm font-medium text-ink-graphite hover:text-accent-orange transition-colors relative group"
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-accent-orange transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
          <div className="flex items-center space-x-4 ml-4 border-l border-bg-light pl-6">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-accent-orange transition-colors">
              <Instagram size={18} />
            </a>
            <a href="mailto:contact@notelegfx.com" className="hover:text-accent-orange transition-colors">
              <Mail size={18} />
            </a>
          </div>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden" onClick={() => setIsMobileMenuOpen(true)}>
          <Menu size={24} />
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 bg-bg-white z-[60] flex flex-col p-8"
          >
            <div className="flex justify-between items-center mb-12">
              <span className="text-2xl font-display font-bold">NOTELEGFX</span>
              <button onClick={() => setIsMobileMenuOpen(false)}><X size={24} /></button>
            </div>
            <div className="flex flex-col space-y-6">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-3xl font-display font-bold hover:text-accent-orange transition-colors"
                >
                  {link.name}
                </a>
              ))}
            </div>
            <div className="mt-auto flex space-x-6">
              <a href="#" className="flex items-center space-x-2 text-ink-graphite">
                <Instagram size={20} /> <span>Instagram</span>
              </a>
              <a href="#" className="flex items-center space-x-2 text-ink-graphite">
                <Mail size={20} /> <span>Email</span>
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const ProjectCard = ({ project, onClick }: { project: Project, onClick: () => void, key?: string }) => {
  return (
    <motion.div 
      whileHover={{ y: -10 }}
      className="group cursor-pointer bg-bg-white border border-bg-light p-4 shadow-sm hover:shadow-xl transition-all duration-500"
      onClick={onClick}
    >
      <div className="relative aspect-[4/5] overflow-hidden mb-6">
        <img 
          src={project.image} 
          alt={project.title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-ink-dark/60 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
          <p className="text-bg-white text-sm mb-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-500 delay-100">
            {project.category}
          </p>
          <h3 className="text-bg-white text-2xl font-display font-bold translate-y-4 group-hover:translate-y-0 transition-transform duration-500 delay-200">
            {project.title}
          </h3>
        </div>
      </div>
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-display font-bold">{project.title}</h3>
          <p className="text-sm text-ink-graphite">{project.category}</p>
        </div>
        <div className="w-10 h-10 rounded-full border border-bg-light flex items-center justify-center group-hover:bg-accent-orange group-hover:border-accent-orange group-hover:text-bg-white transition-all">
          <ArrowRight size={18} />
        </div>
      </div>
    </motion.div>
  );
};

const CaseStudyModal = ({ project, onClose }: { project: Project | null, onClose: () => void }) => {
  if (!project) return null;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-12 bg-ink-dark/90 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div 
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
        className="bg-bg-white w-full max-w-5xl max-h-full overflow-y-auto relative p-8 md:p-16"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose}
          className="absolute top-8 right-8 p-2 hover:bg-bg-soft rounded-full transition-colors"
        >
          <X size={24} />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div>
              <p className="text-accent-orange font-medium mb-2 uppercase tracking-widest text-xs">{project.category}</p>
              <h2 className="text-4xl md:text-6xl font-display font-bold leading-tight">{project.title}</h2>
            </div>
            
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-ink-graphite">Concept</h4>
              <p className="text-lg leading-relaxed text-ink-graphite">{project.description}</p>
            </div>

            <div className="flex flex-wrap gap-3">
              {project.tools.map(tool => (
                <span key={tool} className="px-4 py-2 bg-bg-soft text-xs font-bold uppercase tracking-tighter border border-bg-light">
                  {tool}
                </span>
              ))}
            </div>

            <div className="space-y-4 pt-8 border-t border-bg-light">
              <h4 className="text-sm font-bold uppercase tracking-wider text-ink-graphite">Design Process</h4>
              <p className="text-ink-graphite leading-relaxed">{project.process}</p>
            </div>

            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-ink-graphite">Outcome</h4>
              <p className="text-ink-graphite leading-relaxed">{project.outcome}</p>
            </div>
          </div>

          <div className="space-y-6">
            <img 
              src={project.image} 
              alt={project.title} 
              className="w-full h-auto shadow-2xl border border-bg-light"
              referrerPolicy="no-referrer"
            />
            <img 
              src={`https://picsum.photos/seed/${project.id}-alt/800/1000`} 
              alt="Process detail" 
              className="w-full h-auto shadow-xl border border-bg-light opacity-80"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

// --- Main App ---

export default function App() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <div className="relative min-h-screen selection:bg-accent-orange selection:text-white">
      <Navbar />
      
      {/* Global Ruler Decoration */}
      <div className="fixed top-0 left-0 w-8 h-full border-r border-bg-light z-40 hidden lg:block bg-bg-white">
        <div className="h-full w-full ruler-marks-v opacity-30" />
      </div>
      <div className="fixed top-0 right-0 w-8 h-full border-l border-bg-light z-40 hidden lg:block bg-bg-white">
        <div className="h-full w-full ruler-marks-v opacity-30" />
      </div>

      {/* Hero Section */}
      <section id="home" ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        <div className="absolute inset-0 grid-pattern opacity-40" />
        <Ruler />
        
        <motion.div style={{ y, opacity }} className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="mb-8 inline-block"
          >
            <div className="w-48 h-48 md:w-64 md:h-64 mx-auto overflow-hidden border-4 border-bg-light shadow-2xl bg-ink-dark rounded-full">
              <img 
                src="https://i.ibb.co/V0050rc0/Whats-App-Image-2026-01-16-at-8-52-05-PM.jpg" 
                alt="NOTELEGFX Logo" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>

          <motion.h1 
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-6xl md:text-9xl font-display font-bold tracking-tighter mb-6 leading-[0.85]"
          >
            NOTELE<span className="text-accent-orange">GFX</span>
          </motion.h1>

          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="flex items-center justify-center space-x-4 mb-8 text-sm md:text-lg font-medium tracking-[0.3em] uppercase text-ink-graphite"
          >
            <span>Creative</span>
            <span className="w-1.5 h-1.5 bg-accent-orange rounded-full" />
            <span>Modern</span>
            <span className="w-1.5 h-1.5 bg-accent-orange rounded-full" />
            <span>Premium</span>
          </motion.div>

          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="max-w-2xl mx-auto text-lg md:text-xl text-ink-graphite mb-12 leading-relaxed"
          >
            Visual designer specializing in poster design, social media creatives, and AI-assisted visual concepts.
          </motion.p>

          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-6"
          >
            <a href="#projects" className="px-10 py-5 bg-ink-dark text-bg-white font-bold uppercase tracking-widest text-sm hover:bg-accent-orange transition-all duration-300 shadow-lg hover:shadow-accent-orange/20">
              View Work
            </a>
            <a href="#contact" className="px-10 py-5 border-2 border-ink-dark text-ink-dark font-bold uppercase tracking-widest text-sm hover:bg-ink-dark hover:text-bg-white transition-all duration-300">
              Contact Me
            </a>
          </motion.div>
        </motion.div>

        {/* Decorative elements */}
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center animate-bounce opacity-40">
          <span className="text-[10px] uppercase tracking-[0.5em] mb-2">Scroll</span>
          <div className="w-px h-12 bg-ink-dark" />
        </div>
      </section>

      <TornPaperDivider />

      {/* About Section */}
      <section id="about" className="py-24 md:py-40 bg-bg-soft relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
            <motion.div 
              initial={{ x: -50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div className="inline-block px-4 py-1 border border-ink-dark text-[10px] uppercase tracking-widest font-bold">
                About the Designer
              </div>
              <h2 className="text-5xl md:text-7xl font-display font-bold leading-tight">
                Crafting Visual <br /> <span className="text-accent-orange">Storytelling.</span>
              </h2>
              <p className="text-xl text-ink-graphite leading-relaxed max-w-xl">
                Designer: <span className="text-ink-dark font-bold">Rudra</span>
                <br /><br />
                Self-taught graphic designer focused on visual storytelling and premium aesthetics. I bridge the gap between traditional design principles and futuristic AI-assisted concepts.
              </p>
              
              <div className="pt-12">
                <h4 className="text-xs font-bold uppercase tracking-widest mb-6 text-ink-graphite">Tools of the Trade</h4>
                <div className="flex flex-wrap gap-8">
                  {['Photoshop', 'Photopea', 'Canva'].map(tool => (
                    <div key={tool} className="flex flex-col items-center space-y-2 group">
                      <div className="w-16 h-16 bg-bg-white border border-bg-light flex items-center justify-center shadow-sm group-hover:shadow-md group-hover:border-accent-orange transition-all duration-300">
                        <span className="text-xs font-bold">{tool[0]}</span>
                      </div>
                      <span className="text-[10px] font-bold uppercase tracking-tighter">{tool}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ x: 50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="grid grid-cols-1 sm:grid-cols-2 gap-6"
            >
              {[
                { title: 'Poster Design', icon: <Layout />, desc: 'High-impact visuals for print and digital.' },
                { title: 'Social Media', icon: <Smartphone />, desc: 'Engaging creatives for modern platforms.' },
                { title: 'AI Concepts', icon: <Cpu />, desc: 'Futuristic visual explorations.' },
                { title: 'Visual Branding', icon: <Palette />, desc: 'Cohesive identities for creative brands.' }
              ].map((area, idx) => (
                <div key={idx} className="bg-bg-white p-8 border border-bg-light shadow-sm hover:shadow-xl transition-all duration-500 group">
                  <div className="w-12 h-12 bg-bg-soft flex items-center justify-center mb-6 group-hover:bg-accent-orange group-hover:text-bg-white transition-colors">
                    {area.icon}
                  </div>
                  <h3 className="text-xl font-display font-bold mb-3">{area.title}</h3>
                  <p className="text-sm text-ink-graphite leading-relaxed">{area.desc}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
        <Ruler orientation="vertical" />
      </section>

      <TornPaperDivider top />

      {/* Projects Section */}
      <section id="projects" className="py-24 md:py-40 bg-bg-white relative">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
            <div className="space-y-4">
              <div className="inline-block px-4 py-1 border border-ink-dark text-[10px] uppercase tracking-widest font-bold">
                Portfolio
              </div>
              <h2 className="text-5xl md:text-7xl font-display font-bold">Selected Works</h2>
            </div>
            <p className="max-w-xs text-ink-graphite text-sm leading-relaxed">
              A curated selection of projects that showcase my focus on premium aesthetics and visual impact.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {PROJECTS.map((project) => (
              <ProjectCard 
                key={project.id} 
                project={project} 
                onClick={() => setSelectedProject(project)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 md:py-40 bg-bg-soft relative">
        <div className="absolute inset-0 grid-pattern opacity-20" />
        <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
          <div className="text-center mb-20 space-y-4">
            <div className="inline-block px-4 py-1 border border-ink-dark text-[10px] uppercase tracking-widest font-bold">
              Services
            </div>
            <h2 className="text-5xl md:text-7xl font-display font-bold">What I Offer</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-bg-light border border-bg-light">
            {[
              { title: 'Poster Design', desc: 'Custom posters for events, brands, or personal collections.' },
              { title: 'Social Media', desc: 'Premium content creation for Instagram, Twitter, and more.' },
              { title: 'Brand Identity', desc: 'Developing unique visual languages for modern businesses.' },
              { title: 'AI Design', desc: 'Leveraging cutting-edge AI to create unique visual assets.' }
            ].map((service, idx) => (
              <div key={idx} className="bg-bg-white p-12 hover:bg-bg-soft transition-colors duration-500 group">
                <span className="text-4xl font-display font-bold text-bg-light group-hover:text-accent-orange transition-colors mb-8 block">
                  0{idx + 1}
                </span>
                <h3 className="text-2xl font-display font-bold mb-4">{service.title}</h3>
                <p className="text-ink-graphite text-sm leading-relaxed">{service.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 md:py-40 bg-ink-dark text-bg-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="h-full w-full grid-pattern" />
        </div>
        
        <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10 text-center">
          <motion.div 
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="space-y-12"
          >
            <h2 className="text-5xl md:text-8xl font-display font-bold leading-tight tracking-tighter">
              Let's Build Something <br /> <span className="text-accent-orange italic">Premium</span> Together
            </h2>
            
            <div className="flex flex-col md:flex-row items-center justify-center gap-8 pt-12">
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group flex items-center space-x-4 px-8 py-6 bg-bg-white text-ink-dark font-bold uppercase tracking-widest text-sm hover:bg-accent-orange hover:text-bg-white transition-all duration-500 w-full md:w-auto"
              >
                <Instagram size={24} />
                <span>Instagram Contact</span>
                <ChevronRight className="group-hover:translate-x-2 transition-transform" />
              </a>
              <a 
                href="mailto:contact@notelegfx.com"
                className="group flex items-center space-x-4 px-8 py-6 border-2 border-bg-white text-bg-white font-bold uppercase tracking-widest text-sm hover:bg-bg-white hover:text-ink-dark transition-all duration-500 w-full md:w-auto"
              >
                <Mail size={24} />
                <span>Email Inquiry</span>
                <ChevronRight className="group-hover:translate-x-2 transition-transform" />
              </a>
            </div>

            <div className="pt-20 grid grid-cols-1 md:grid-cols-2 gap-12 border-t border-bg-white/10 max-w-3xl mx-auto">
              <div className="space-y-2">
                <p className="text-bg-white/40 text-[10px] uppercase tracking-[0.3em]">Instagram Handle</p>
                <p className="text-xl font-display font-bold">@NOTELEGFX</p>
              </div>
              <div className="space-y-2">
                <p className="text-bg-white/40 text-[10px] uppercase tracking-[0.3em]">Email Address</p>
                <p className="text-xl font-display font-bold">contact@notelegfx.com</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-bg-white border-t border-bg-light">
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col md:flex-row justify-between items-center gap-8">
          <p className="text-xs text-ink-graphite font-medium uppercase tracking-widest">
            © 2026 NOTELEGFX. All Rights Reserved.
          </p>
          <div className="flex items-center space-x-8">
            <a href="#" className="text-xs font-bold uppercase tracking-widest hover:text-accent-orange transition-colors">Privacy Policy</a>
            <a href="#" className="text-xs font-bold uppercase tracking-widest hover:text-accent-orange transition-colors">Terms of Service</a>
          </div>
          <div className="flex items-center space-x-4">
            <a href="#" className="p-2 border border-bg-light hover:border-accent-orange hover:text-accent-orange transition-all">
              <Instagram size={16} />
            </a>
            <a href="#" className="p-2 border border-bg-light hover:border-accent-orange hover:text-accent-orange transition-all">
              <Github size={16} />
            </a>
          </div>
        </div>
      </footer>

      {/* Case Study Modal */}
      <AnimatePresence>
        {selectedProject && (
          <CaseStudyModal 
            project={selectedProject} 
            onClose={() => setSelectedProject(null)} 
          />
        )}
      </AnimatePresence>

      {/* Measurement Guides (Decorative) */}
      <div className="fixed top-1/2 left-0 -translate-y-1/2 -rotate-90 origin-left text-[8px] font-bold uppercase tracking-[1em] text-bg-light pointer-events-none hidden xl:block">
        Measurement Guide 1200px
      </div>
      <div className="fixed top-1/2 right-0 -translate-y-1/2 rotate-90 origin-right text-[8px] font-bold uppercase tracking-[1em] text-bg-light pointer-events-none hidden xl:block">
        Grid System Active
      </div>
    </div>
  );
}
